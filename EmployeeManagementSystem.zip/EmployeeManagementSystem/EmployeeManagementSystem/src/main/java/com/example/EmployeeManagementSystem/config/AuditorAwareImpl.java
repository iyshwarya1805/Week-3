
package com.example.EmployeeManagementSystem.config;

import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class AuditorAwareImpl implements AuditorAware<String> {

    @Override
    public Optional<String> getCurrentAuditor() {
        // Here, you would typically get the current user's username.
        // This example returns a placeholder string.
        // In a real application, this might come from the SecurityContext or a similar context.

        return Optional.of("system"); // Replace with actual user retrieval logic
    }
}
