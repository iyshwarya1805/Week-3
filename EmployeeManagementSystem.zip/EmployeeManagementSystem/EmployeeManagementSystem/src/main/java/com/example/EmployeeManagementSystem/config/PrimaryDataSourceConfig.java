package com.example.EmployeeManagementSystem.config;

import org.springframework.beans.factory.annotation.Primary;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import jakarta.annotation.Priority;

import javax.sql.DataSource;

@Configuration
public class PrimaryDataSourceConfig {

    @Bean
    @Priority(value = 0)
    @ConfigurationProperties("spring.datasource.primary")
    public DataSourceBuilder<?> primaryDataSourceProperties() {
        return DataSourceBuilder.create();
    }

    @Bean
    @Priority(value = 0)
    public DataSource primaryDataSource() {
        return primaryDataSourceProperties().build();
    }
}
