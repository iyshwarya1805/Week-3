
package com.example.EmployeeManagementSystem.controller;

import com.example.EmployeeManagementSystem.model.Employee;
import com.example.EmployeeManagementSystem.model.EmployeeDTO;
import com.example.EmployeeManagementSystem.model.EmployeeNameProjection;
import com.example.EmployeeManagementSystemrepository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/employees")
public class EmployeeController {


    @Autowired
    
    private EmployeeRepository employeeRepository;
	private Object employeeService;
    public EmployeeController(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }
    @GetMapping("/projections")
    public List<EmployeeNameProjection> getAllEmployeeProjections() {
        return employeeRepository.findAllProjectedBy();
    }

    // Method to get class-based projections
    @GetMapping("/dtos")
    public List<EmployeeDTO> getAllEmployeeDTOs() {
        return employeeRepository.findAllEmployeeDTOs();
    }

    @GetMapping
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    @PostMapping
    public ResponseEntity<Employee> createEmployee(@RequestBody Employee employee) {
        Employee savedEmployee = employeeRepository.save(employee);
        return new ResponseEntity<>(savedEmployee, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable Long id) {
        return employeeRepository.findById(id)
            .map(employee -> new ResponseEntity<>(employee, HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Employee> updateEmployee(@PathVariable Long id, @RequestBody Employee employee) {
        if (!employeeRepository.existsById(id)) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        employee.setId(id);
        Employee updatedEmployee = employeeRepository.save(employee);
        return new ResponseEntity<>(updatedEmployee, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEmployee(@PathVariable Long id) {
        if (!employeeRepository.existsById(id)) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        employeeRepository.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    @GetMapping("/test")
    public String testEndpoint() {
        return "Test successful!";
    }
    @PostMapping("/batch")
    public ResponseEntity<Void> createEmployeesBatch(@RequestBody List<EmployeeDTO> employeeDTOs) {
        List<Employee> employees = new ArrayList<>();
        for (EmployeeDTO dto : employeeDTOs) {
            Employee employee = new Employee();
            employee.setName(dto.getName());
            
            // Set department if needed
            employees.add(employee);
        }
       
        return new ResponseEntity<>(HttpStatus.CREATED);
    }


}
