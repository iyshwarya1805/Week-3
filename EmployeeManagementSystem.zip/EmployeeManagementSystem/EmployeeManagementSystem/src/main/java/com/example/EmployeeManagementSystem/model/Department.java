package com.example.EmployeeManagementSystem.model;
//Department.java


import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Getter
@Setter
public class Department {
 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long id;
 private String name;

 @OneToMany(mappedBy = "department")
 private List<Employee> employees;
 @CreatedDate
 @Column(updatable = false)
 private LocalDateTime createdDate;

 @LastModifiedDate
 private LocalDateTime lastModifiedDate;

 @CreatedBy
 @Column(updatable = false)
 private String createdBy;

 @LastModifiedBy
 private String lastModifiedBy;

public void setId(Long id2) {
	// TODO Auto-generated method stub
	
}
}

