
package com.example.EmployeeManagementSystem.model;

public class DepartmentDTO {
    private String name;

    public DepartmentDTO(String name) {
        this.name = name;
    }

    // Getters and setters
}
