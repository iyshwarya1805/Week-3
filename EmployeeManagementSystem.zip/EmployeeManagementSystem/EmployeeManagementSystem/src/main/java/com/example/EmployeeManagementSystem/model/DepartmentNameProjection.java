
package com.example.EmployeeManagementSystem.model;

public interface DepartmentNameProjection {
    String getName();
}
