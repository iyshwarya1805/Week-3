package com.example.EmployeeManagementSystem.model;
//Employee.java

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Getter
@Setter
@NamedQuery(
	    name = "Employee.findByDepartment",
	    query = "SELECT e FROM Employee e WHERE e.department.id = :departmentId"
	)

@Table(name = "employee")
@DynamicInsert
@DynamicUpdate	
public class Employee {
 @Id
 
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long id;
 private String name;
 
 private String email;

 @ManyToOne
 @JoinColumn(name = "department_id")
 @BatchSize(size = 10)
 private Department department;
 @CreatedDate
 @Column(updatable = false)
 private LocalDateTime createdDate;

 @LastModifiedDate
 private LocalDateTime lastModifiedDate;

 @CreatedBy
 @Column(updatable = false)
 private String createdBy;

 @LastModifiedBy
 private String lastModifiedBy;

public void setId(Long id2) {
	// TODO Auto-generated method stub
	
}



public void setEmail(String email2) {
	// TODO Auto-generated method stub
	
}

public void setName(String name2) {
	// TODO Auto-generated method stub
	
}



 





}
 

