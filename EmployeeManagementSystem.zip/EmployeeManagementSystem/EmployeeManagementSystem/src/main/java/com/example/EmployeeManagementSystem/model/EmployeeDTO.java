


    

    // Getters and setters

package com.example.EmployeeManagementSystem.model;

public class EmployeeDTO {
    private String name;
    private String email;
    private Long departmentId; // Assuming you have a department ID
    public EmployeeDTO(String name, String email) {
        this.name = name;
        this.email = email;
    }
    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Long getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Long departmentId) {
        this.departmentId = departmentId;
    }
}

