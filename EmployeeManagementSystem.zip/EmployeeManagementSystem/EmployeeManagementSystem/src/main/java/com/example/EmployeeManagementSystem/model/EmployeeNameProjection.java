
package com.example.EmployeeManagementSystem.model;

public interface EmployeeNameProjection {
    String getName();
    String getEmail();
}
