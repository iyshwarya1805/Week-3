package com.example.EmployeeManagementSystemrepository;



import com.example.EmployeeManagementSystem.model.Department;
import com.example.EmployeeManagementSystem.model.DepartmentDTO;
import com.example.EmployeeManagementSystem.model.DepartmentNameProjection;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long> {
    // Derived query method to find department by name
    Department findByName(String name);
    List<DepartmentNameProjection> findAllProjectedBy();
    @Query("SELECT new com.example.EmployeeManagementSystem.model.DepartmentDTO(d.name) FROM Department d")
    List<DepartmentDTO> findAllDepartmentDTOs();
}
