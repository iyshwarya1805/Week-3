package com.example.EmployeeManagementSystemrepository;



import com.example.EmployeeManagementSystem.model.Employee;
import com.example.EmployeeManagementSystem.model.EmployeeDTO;
import com.example.EmployeeManagementSystem.model.EmployeeNameProjection;

import org.hibernate.query.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.awt.print.Pageable;
import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    // Derived query method to find employees by department name
    List<Employee> findByDepartmentName(Long department_id);
    @Query("SELECT e FROM Employee e WHERE e.email = ?1")
    Employee findByEmail(String email);
    @Query(name = "Employee.findByDepartment")
    List<Employee> findByDepartment(@Param("departmentId") Long department_id);
    Page findAll(Pageable pageable);
    List<EmployeeNameProjection> findAllProjectedBy();
    @Query("SELECT new com.example.EmployeeManagementSystem.model.EmployeeDTO(e.name, e.email) FROM Employee e")
    List<EmployeeDTO> findAllEmployeeDTOs();
}
