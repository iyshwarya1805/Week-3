package org.springframework.beans.factory.annotation;

public class Primary {

}
